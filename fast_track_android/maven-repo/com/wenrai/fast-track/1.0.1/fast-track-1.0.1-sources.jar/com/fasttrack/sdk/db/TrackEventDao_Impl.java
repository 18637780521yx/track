package com.fasttrack.sdk.db;

import android.database.Cursor;
import android.os.CancellationSignal;
import androidx.annotation.NonNull;
import androidx.room.CoroutinesRoom;
import androidx.room.EntityInsertionAdapter;
import androidx.room.RoomDatabase;
import androidx.room.RoomSQLiteQuery;
import androidx.room.SharedSQLiteStatement;
import androidx.room.util.CursorUtil;
import androidx.room.util.DBUtil;
import androidx.room.util.StringUtil;
import androidx.sqlite.db.SupportSQLiteStatement;
import java.lang.Class;
import java.lang.Exception;
import java.lang.Integer;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.lang.StringBuilder;
import java.lang.SuppressWarnings;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Callable;
import javax.annotation.processing.Generated;
import kotlin.Unit;
import kotlin.coroutines.Continuation;

@Generated("androidx.room.RoomProcessor")
@SuppressWarnings({"unchecked", "deprecation"})
public final class TrackEventDao_Impl implements TrackEventDao {
  private final RoomDatabase __db;

  private final EntityInsertionAdapter<TrackEventEntity> __insertionAdapterOfTrackEventEntity;

  private final SharedSQLiteStatement __preparedStmtOfDeleteOldest;

  public TrackEventDao_Impl(@NonNull final RoomDatabase __db) {
    this.__db = __db;
    this.__insertionAdapterOfTrackEventEntity = new EntityInsertionAdapter<TrackEventEntity>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "INSERT OR ABORT INTO `track_events` (`eventId`,`name`,`propertiesJson`,`commonPropertiesJson`,`distinctId`,`anonymousId`,`sessionId`,`timestampMs`) VALUES (?,?,?,?,?,?,?,?)";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final TrackEventEntity entity) {
        statement.bindString(1, entity.getEventId());
        statement.bindString(2, entity.getName());
        statement.bindString(3, entity.getPropertiesJson());
        statement.bindString(4, entity.getCommonPropertiesJson());
        if (entity.getDistinctId() == null) {
          statement.bindNull(5);
        } else {
          statement.bindString(5, entity.getDistinctId());
        }
        statement.bindString(6, entity.getAnonymousId());
        statement.bindString(7, entity.getSessionId());
        statement.bindLong(8, entity.getTimestampMs());
      }
    };
    this.__preparedStmtOfDeleteOldest = new SharedSQLiteStatement(__db) {
      @Override
      @NonNull
      public String createQuery() {
        final String _query = "\n"
                + "        DELETE FROM track_events WHERE eventId IN (\n"
                + "            SELECT eventId FROM track_events ORDER BY timestampMs ASC LIMIT ?\n"
                + "        )\n"
                + "        ";
        return _query;
      }
    };
  }

  @Override
  public Object insert(final TrackEventEntity event, final Continuation<? super Unit> $completion) {
    return CoroutinesRoom.execute(__db, true, new Callable<Unit>() {
      @Override
      @NonNull
      public Unit call() throws Exception {
        __db.beginTransaction();
        try {
          __insertionAdapterOfTrackEventEntity.insert(event);
          __db.setTransactionSuccessful();
          return Unit.INSTANCE;
        } finally {
          __db.endTransaction();
        }
      }
    }, $completion);
  }

  @Override
  public Object deleteOldest(final int n, final Continuation<? super Unit> $completion) {
    return CoroutinesRoom.execute(__db, true, new Callable<Unit>() {
      @Override
      @NonNull
      public Unit call() throws Exception {
        final SupportSQLiteStatement _stmt = __preparedStmtOfDeleteOldest.acquire();
        int _argIndex = 1;
        _stmt.bindLong(_argIndex, n);
        try {
          __db.beginTransaction();
          try {
            _stmt.executeUpdateDelete();
            __db.setTransactionSuccessful();
            return Unit.INSTANCE;
          } finally {
            __db.endTransaction();
          }
        } finally {
          __preparedStmtOfDeleteOldest.release(_stmt);
        }
      }
    }, $completion);
  }

  @Override
  public Object count(final Continuation<? super Integer> $completion) {
    final String _sql = "SELECT COUNT(*) FROM track_events";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 0);
    final CancellationSignal _cancellationSignal = DBUtil.createCancellationSignal();
    return CoroutinesRoom.execute(__db, false, _cancellationSignal, new Callable<Integer>() {
      @Override
      @NonNull
      public Integer call() throws Exception {
        final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
        try {
          final Integer _result;
          if (_cursor.moveToFirst()) {
            final int _tmp;
            _tmp = _cursor.getInt(0);
            _result = _tmp;
          } else {
            _result = 0;
          }
          return _result;
        } finally {
          _cursor.close();
          _statement.release();
        }
      }
    }, $completion);
  }

  @Override
  public Object loadOldest(final int limit,
      final Continuation<? super List<TrackEventEntity>> $completion) {
    final String _sql = "SELECT * FROM track_events ORDER BY timestampMs ASC LIMIT ?";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 1);
    int _argIndex = 1;
    _statement.bindLong(_argIndex, limit);
    final CancellationSignal _cancellationSignal = DBUtil.createCancellationSignal();
    return CoroutinesRoom.execute(__db, false, _cancellationSignal, new Callable<List<TrackEventEntity>>() {
      @Override
      @NonNull
      public List<TrackEventEntity> call() throws Exception {
        final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
        try {
          final int _cursorIndexOfEventId = CursorUtil.getColumnIndexOrThrow(_cursor, "eventId");
          final int _cursorIndexOfName = CursorUtil.getColumnIndexOrThrow(_cursor, "name");
          final int _cursorIndexOfPropertiesJson = CursorUtil.getColumnIndexOrThrow(_cursor, "propertiesJson");
          final int _cursorIndexOfCommonPropertiesJson = CursorUtil.getColumnIndexOrThrow(_cursor, "commonPropertiesJson");
          final int _cursorIndexOfDistinctId = CursorUtil.getColumnIndexOrThrow(_cursor, "distinctId");
          final int _cursorIndexOfAnonymousId = CursorUtil.getColumnIndexOrThrow(_cursor, "anonymousId");
          final int _cursorIndexOfSessionId = CursorUtil.getColumnIndexOrThrow(_cursor, "sessionId");
          final int _cursorIndexOfTimestampMs = CursorUtil.getColumnIndexOrThrow(_cursor, "timestampMs");
          final List<TrackEventEntity> _result = new ArrayList<TrackEventEntity>(_cursor.getCount());
          while (_cursor.moveToNext()) {
            final TrackEventEntity _item;
            final String _tmpEventId;
            _tmpEventId = _cursor.getString(_cursorIndexOfEventId);
            final String _tmpName;
            _tmpName = _cursor.getString(_cursorIndexOfName);
            final String _tmpPropertiesJson;
            _tmpPropertiesJson = _cursor.getString(_cursorIndexOfPropertiesJson);
            final String _tmpCommonPropertiesJson;
            _tmpCommonPropertiesJson = _cursor.getString(_cursorIndexOfCommonPropertiesJson);
            final String _tmpDistinctId;
            if (_cursor.isNull(_cursorIndexOfDistinctId)) {
              _tmpDistinctId = null;
            } else {
              _tmpDistinctId = _cursor.getString(_cursorIndexOfDistinctId);
            }
            final String _tmpAnonymousId;
            _tmpAnonymousId = _cursor.getString(_cursorIndexOfAnonymousId);
            final String _tmpSessionId;
            _tmpSessionId = _cursor.getString(_cursorIndexOfSessionId);
            final long _tmpTimestampMs;
            _tmpTimestampMs = _cursor.getLong(_cursorIndexOfTimestampMs);
            _item = new TrackEventEntity(_tmpEventId,_tmpName,_tmpPropertiesJson,_tmpCommonPropertiesJson,_tmpDistinctId,_tmpAnonymousId,_tmpSessionId,_tmpTimestampMs);
            _result.add(_item);
          }
          return _result;
        } finally {
          _cursor.close();
          _statement.release();
        }
      }
    }, $completion);
  }

  @Override
  public Object deleteByIds(final List<String> ids, final Continuation<? super Unit> $completion) {
    return CoroutinesRoom.execute(__db, true, new Callable<Unit>() {
      @Override
      @NonNull
      public Unit call() throws Exception {
        final StringBuilder _stringBuilder = StringUtil.newStringBuilder();
        _stringBuilder.append("DELETE FROM track_events WHERE eventId IN (");
        final int _inputSize = ids.size();
        StringUtil.appendPlaceholders(_stringBuilder, _inputSize);
        _stringBuilder.append(")");
        final String _sql = _stringBuilder.toString();
        final SupportSQLiteStatement _stmt = __db.compileStatement(_sql);
        int _argIndex = 1;
        for (String _item : ids) {
          _stmt.bindString(_argIndex, _item);
          _argIndex++;
        }
        __db.beginTransaction();
        try {
          _stmt.executeUpdateDelete();
          __db.setTransactionSuccessful();
          return Unit.INSTANCE;
        } finally {
          __db.endTransaction();
        }
      }
    }, $completion);
  }

  @NonNull
  public static List<Class<?>> getRequiredConverters() {
    return Collections.emptyList();
  }
}
